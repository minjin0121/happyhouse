package com.ssafy.happyhouse.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.model.dto.Prefer;
import com.ssafy.happyhouse.model.service.PreferService;

@CrossOrigin
@RestController
public class PreferController {

	@Autowired
	PreferService service;
	
	@GetMapping("/prefer/{id}")
    public List<Prefer> selectPrefer(@PathVariable String id) {
		return service.selectPrefer(id);
	}

	@PostMapping("/prefer/insert")
	public boolean insert(@RequestBody Prefer prefer) { // 회원 정보 삭제
		System.out.println();
		try {
			service.insertPrefer(prefer);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	@GetMapping("/prefer/delete/{id}/{code}")
	public boolean delete(@PathVariable String id, @PathVariable String code) {
		System.out.println(id + " " + code);
		try {
			service.deletePrefer(id, code);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
}
