package com.ssafy.happyhouse.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.model.dto.Member;
import com.ssafy.happyhouse.model.service.MemberService;

@CrossOrigin
@RestController
public class MemberController {

	@Autowired
	MemberService service;

	@PostMapping("/member/signin")
	public boolean signin(@RequestBody Member member) { // 회원가입 처리
		System.out.println("Signin Member : " + member.getMemberID() + " / " + member.getMemberPW());
		try{
			service.signin(member);
			return true;
		}catch(Exception e){
			e.printStackTrace();
	        return false;
		}
	}
	
	@PostMapping("/member/signin/{id}")
	public int confirmId(@PathVariable String id) { // 회원가입 처리
		System.out.println(id);
		try{
			return service.confirmId(id);
		}catch(Exception e){
			e.printStackTrace();
	        return 0;
		}
	}
	
	@PostMapping("/member/login")
    public boolean login(@RequestBody Member member, HttpSession session) throws Exception { // 로그인 처리
		System.out.println("ID : " + member.getMemberID() + " / PW : " + member.getMemberPW());
    	String id = member.getMemberID();
    	String pw = member.getMemberPW();
    	Member result = service.login(id, pw);
		if (result == null) {
			return false;
		}
		else {
			System.out.println(member + " / " + member.getMemberNAME());
			session.setAttribute("memberID", id);
			session.setAttribute("memberPW", pw);
			return true;
		}
    }

	@GetMapping("/member/info/{id}")
    public Member infoView(@PathVariable String id) {
		return service.infoView(id);
	}
	
	@PutMapping("/member")
	public boolean update(@RequestBody Member member) { // 회원 정보 수정
		try {
			System.out.println(member.getMemberID() + " " + member.getMemberPW());
			service.memberUpdate(member);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;	
	}
	
//	@GetMapping("/member/delete/{id}")
//	public boolean delete(@PathVariable String id) { // 회원 정보 삭제
//		try {
//			service.delete(id);
//			//System.out.println("회원 정보 삭제 : " + memberID + " / " + memberPW);
//		} catch (Exception e) {
//			e.printStackTrace();
//			return false;
//		}
//		return true;	
//	}
	
	@GetMapping("/member/logout")
	public String logout(HttpSession session) { // 로그아웃 처리
		session.removeAttribute("memberID");
		return "redirect:/";	
	}
}
