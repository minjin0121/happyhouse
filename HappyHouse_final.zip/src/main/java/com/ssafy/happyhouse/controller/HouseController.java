package com.ssafy.happyhouse.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.model.dto.Board;
import com.ssafy.happyhouse.model.dto.HouseDeal;
import com.ssafy.happyhouse.model.dto.HouseInfo;
import com.ssafy.happyhouse.model.dto.SidoGugunCode;
import com.ssafy.happyhouse.model.service.HouseService;

@CrossOrigin
@RestController
public class HouseController {

	@Autowired
	HouseService service;

	@GetMapping(value="/list/{keyword}")
	public List<String> houseSearch(@PathVariable String keyword) {
		System.out.println("houseSearch : " + keyword);
		List<SidoGugunCode> donglist = null;
		List<HouseInfo> aptlist = null;
		List<String> result = new ArrayList<>(); // list에 {지역명/아파트명 여부, 지역이름/아파트이름, 시, 구, 동} 이렇게 넣어서 return
		
		try {
			donglist = service.getDongName(keyword); // keyword를 동 DB에서 검색 일치하는 값
			aptlist = service.getAptName(keyword); // keyword를 houseinfo DB에서 검색 일치하는 값
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		for (int t = 0; t < donglist.size(); t++) {
			result.add("dong");
			result.add(donglist.get(t).getSidoCode());
			result.add(donglist.get(t).getGugunName());
			result.add(donglist.get(t).getSidoName() + " " + donglist.get(t).getGugunCode() + " " + donglist.get(t).getGugunName());
		}
		for (int t = 0; t < aptlist.size(); t++) {
			result.add("apt");
			result.add(aptlist.get(t).getCode());
			result.add(aptlist.get(t).getAptName());
			result.add(aptlist.get(t).getLat()+ " " + aptlist.get(t).getLng()+ " " + aptlist.get(t).getDong());
			result.add(aptlist.get(t).getNo());
		}
		System.out.println(result);
		// list에 전체 값 넣어서 return
		return result;
	}
	
	@GetMapping(value = "/sido")
	public List<SidoGugunCode> getSido() throws Exception {
		List<SidoGugunCode> list = null;
		list = service.getSido();
		return list;
	}
	
	@GetMapping(value = "/gugun/{sido}")
	public List<SidoGugunCode> getGugun(@PathVariable String sido) throws Exception {
		List<SidoGugunCode> list = null;
		list = service.getGugunInSido(sido);
		return list;
	}
	
	@GetMapping(value = "/dong/{gugun}")
	public List<SidoGugunCode> getDong(@PathVariable String gugun) throws Exception {
		List<SidoGugunCode> list = null;
		list = service.getDongInGugun(gugun);
		return list;
	}

	@GetMapping(value = "/result")
	public List<HouseInfo> main(HttpServletRequest request) throws Exception {
		String dong = request.getParameter("dong");
		return service.getAptInDong(dong);
	}

	@GetMapping(value = "/selectAll")
	public List<HouseInfo> selectAll() throws Exception {
		return service.selectAll();
	}

	@GetMapping(value = "/search")
	public List<HouseInfo> search(HttpServletRequest request) throws Exception {
		String dong = request.getParameter("dong");
		String aptName = request.getParameter("aptName");
		return service.search(aptName, dong);
	}

	@GetMapping(value = "/detail/{dong}/{aptName}")
	public List<HouseDeal> detail(@PathVariable String dong, @PathVariable String aptName) throws Exception {
		return service.detail(aptName, dong);
	}
	
	@GetMapping(value="/house/{dong}")
	public List<HouseDeal> listByDong(@PathVariable String dong) {
		return service.listByDong(dong);
	}
	
	@GetMapping(value="/houseInfo/{no}")
	public List<HouseInfo> houseInfo(@PathVariable String no) {
		return service.houseInfo(no);
	}
	
	@PostMapping(value="/makeAddr")
	public HouseInfo makeAddress(@RequestBody HouseInfo info) {
		return service.makeAddress(info);
	}
}
