package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.model.dto.Prefer;

public interface PreferService {

	public void insertPrefer(Prefer prefer);
	public List<Prefer> selectPrefer(String id);
	public void deletePrefer(String id, String code);

}
