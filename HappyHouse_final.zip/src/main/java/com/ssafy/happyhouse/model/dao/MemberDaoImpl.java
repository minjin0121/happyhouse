package com.ssafy.happyhouse.model.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.ssafy.happyhouse.mapper.MemberMapper;
import com.ssafy.happyhouse.model.dto.Member;
import com.ssafy.happyhouse.model.dto.Prefer;

@Repository
public class MemberDaoImpl implements MemberDao {

	@Autowired
	MemberMapper mapper;
	
	@Override
	public Member login(String ID, String PW) throws Exception {
		return mapper.login(ID, PW);
	}
	
	@Override
	public void signin(Member member) throws Exception {
		mapper.signin(member);
	}

	@Override
	public void memberUpdate(Member member) throws Exception {
		mapper.memberUpdate(member);
	}

	@Override
	public void delete(String ID, String PW) throws Exception {
		mapper.delete(ID, PW);
	}

	@Override
	public int confirmId(String id) {
		return mapper.confirmId(id);
	}

	@Override
	public Member infoView(String id) {
		return mapper.infoView(id);
	}

	@Override
	public void insertPrefer(Prefer prefer) {
		mapper.insertPrefer(prefer);
	}

	@Override
	public List<Prefer> selectPrefer(String id) {
		return mapper.selectPrefer(id);
	}

}
