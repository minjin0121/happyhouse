package com.ssafy.happyhouse.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.dao.PreferDao;
import com.ssafy.happyhouse.model.dto.Prefer;

@Service
public class PreferServiceImpl implements PreferService{

	@Autowired
	PreferDao dao;
	
	@Override
	public void insertPrefer(Prefer prefer) {
		dao.insertPrefer(prefer);
	}

	@Override
	public List<Prefer> selectPrefer(String id) {
		return dao.selectPrefer(id);
	}

	@Override
	public void deletePrefer(String id, String code) {
		dao.deletePrefer(id, code);
	}

}
