package com.ssafy.happyhouse.model.dao;

import java.util.List;

import com.ssafy.happyhouse.model.dto.Prefer;

public interface PreferDao {

	public void insertPrefer(Prefer prefer);
	public List<Prefer> selectPrefer(String id);
	public void deletePrefer(String id, String code);

}
