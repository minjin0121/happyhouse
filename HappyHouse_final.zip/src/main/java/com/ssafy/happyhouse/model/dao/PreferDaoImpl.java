package com.ssafy.happyhouse.model.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.happyhouse.mapper.PreferMapper;
import com.ssafy.happyhouse.model.dto.Prefer;

@Repository
public class PreferDaoImpl implements PreferDao{
	
	@Autowired
	PreferMapper mapper;
	
	@Override
	public void insertPrefer(Prefer prefer) {
		mapper.insertPrefer(prefer);
	}

	@Override
	public List<Prefer> selectPrefer(String id) {
		return mapper.selectPrefer(id);
	}

	@Override
	public void deletePrefer(String id, String code) {
		mapper.deletePrefer(id, code);
	}
	
	

}
