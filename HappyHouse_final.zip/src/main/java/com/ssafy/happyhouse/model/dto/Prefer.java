package com.ssafy.happyhouse.model.dto;

public class Prefer {
	
	private String id;
	private String code;
	private String addr;
	
	public Prefer(String id, String code, String addr) {
		this.id = id;
		this.code = code;
		this.addr = addr;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}
	
}
