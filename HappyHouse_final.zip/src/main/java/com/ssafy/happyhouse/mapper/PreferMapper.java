package com.ssafy.happyhouse.mapper;

import java.util.List;

import com.ssafy.happyhouse.model.dto.Prefer;

public interface PreferMapper {

	public void insertPrefer(Prefer prefer);
	public List<Prefer> selectPrefer(String id);
	public void deletePrefer(String id, String code);

}
