package com.ssafy.happyhouse.mapper;

import java.util.List;

import com.ssafy.happyhouse.model.dto.Member;
import com.ssafy.happyhouse.model.dto.Prefer;

public interface MemberMapper {
	
	public Member login(String ID, String PW) throws Exception;
	public void signin(Member member) throws Exception;
	public void memberUpdate(Member member) throws Exception;
	public void delete(String ID, String PW) throws Exception;
	public int confirmId(String id);
	public Member infoView(String id);
	public void insertPrefer(Prefer prefer);
	public List<Prefer> selectPrefer(String id);
	
}
