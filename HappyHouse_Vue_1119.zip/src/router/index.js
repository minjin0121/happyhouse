import Vue from 'vue';
import VueRouter from 'vue-router';
import Home from '../views/Home.vue';
import HouseMain from '../views/HouseMain.vue';
import BoardHome from '../views/BoardHome.vue';
import BoardDetail from '../views/BoardDetail.vue';
import BoardInsert from '../views/BoardInsert.vue';
import BoardUpdate from '../views/BoardUpdate.vue';

Vue.use(VueRouter);

const routes = [
    {
        path: '/',
        name: 'Home',
        component: Home,
    },
    {
        path: '/about',
        name: 'About',
        // route level code-splitting
        // this generates a separate chunk (about.[hash].js) for this route
        // which is lazy-loaded when the route is visited.
        component: () =>
            import(/* webpackChunkName: "about" */ '../views/About.vue'),
    },
    {
        path: '/HouseMain',
        name: 'HouseMain',
        component: HouseMain,
    },
    {
        path: '/BoardHome',
        name: 'BoardHome',
        component: BoardHome,
    },
    {
        path: '/BoardDetail',
        name: 'BoardDetail',
        component: BoardDetail,
    },
    {
        path: '/BoardInsert',
        name: 'BoardInsert',
        component: BoardInsert,
    },
    {
        path: '/BoardUpdate',
        name: 'BoardUpdate',
        component: BoardUpdate,
    },
];

const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL,
    routes,
});

export default router;
