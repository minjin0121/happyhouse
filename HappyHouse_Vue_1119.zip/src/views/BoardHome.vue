<template>
    <div id="BoardHome">
        <img alt="Vue logo" src="../assets/BoardLogo_MJNH.jpg" />
        <div id="BoardInsertWrap">
            <button @click="moveBoardInsert">등록</button>
        </div>
        <div id="BoardSearchWrap">
            <select v-model="type">
                <option value="title">제목</option>
                <option value="name">작성자</option>
            </select>
            &nbsp;
            <input type="text" v-model="keyword" @keyup.enter="search" />&nbsp;
            <button @click="search">검색</button>&nbsp;&nbsp;
            <button @click="selectAll">전체목록</button>
        </div>
        <div id="BoardListWrap">
            <table id="BoardList">
                <colgroup>
                    <col width="6%" />
                    <col width="*" />
                    <col width="12%" />
                    <col width="10%" />
                    <col width="7%" />
                </colgroup>
                <tr>
                    <th>번호</th>
                    <th>제목</th>
                    <th>작성자</th>
                    <th>날짜</th>
                    <th>조회수</th>
                </tr>
                <tr
                    v-for="(board, index) in boardList"
                    :key="index"
                    @click="moveBoardDetail(index)"
                >
                    <td>{{ board.num }}</td>
                    <td>{{ board.title }}</td>
                    <td>{{ board.name }}</td>
                    <td>{{ board.wdate }}</td>
                    <td>{{ board.count }}</td>
                </tr>
            </table>
        </div>
    </div>
</template>

<script>
import axios from 'axios';

export default {
    data() {
        return {
            boardList: '',
            type: 'title',
            keyword: '',
        };
    },
    mounted() {
        this.selectAll();
    },
    methods: {
        selectAll() {
            this.keyword = '';
            axios
                .get('http://localhost/boards')
                .then((response) => {
                    this.boardList = response.data;
                    console.log('SUCCESS : ' + response.data.length);
                })
                .catch((response) => {
                    console.log('FAIL : ' + response.status);
                });
        },
        countUp(num) {
            axios
                .put('http://localhost/boards/' + num)
                .then((response) => {
                    console.log('SUCCESS : ' + response);
                })
                .catch((response) => {
                    console.log('FAIL : ' + response.status);
                });
        },
        moveBoardDetail(index) {
            console.log(
                'sendBoardNum : ' + index + ' / ' + this.boardList[index].num
            );
            this.countUp(this.boardList[index].num);
            this.$router.push({
                path: './BoardDetail',
                query: { num: this.boardList[index].num },
            });
        },
        moveBoardInsert() {
            console.log('moveBoardInsert');
            this.$router.push('./BoardInsert');
        },
        search() {
            console.log('search : ' + this.keyword + ' ' + this.type);
            if (this.type == 'title') {
                axios
                    .get('http://localhost/boards/title/' + this.keyword)
                    .then((response) => {
                        this.boardList = response.data;
                        console.log('SUCCESS : ' + response.data.length);
                    })
                    .catch((response) => {
                        console.log('FAIL : ' + response.status);
                    });
            } else {
                axios
                    .get('http://localhost/boards/name/' + this.keyword)
                    .then((response) => {
                        this.boardList = response.data;
                        console.log('SUCCESS : ' + response.data.length);
                    })
                    .catch((response) => {
                        console.log('FAIL : ' + response.status);
                    });
            }
        },
    },
};
</script>

<style>
#BoardInsertWrap {
    text-align: right;
    margin-right: 10%;
    margin-bottom: 20px;
}
#BoardSearchWrap {
    text-align: right;
    margin-right: 10%;
    margin-bottom: 20px;
}
#BoardList {
    margin: auto;
    margin-bottom: 50px;
    width: 80%;
}
#BoardList th {
    border-top: 1px solid #888;
}
#BoardList th,
#BoardList td {
    border-bottom: 1px solid #eee;
    padding: 5px 0;
}
#BoardList td.txt_left {
    text-align: left;
}
</style>
