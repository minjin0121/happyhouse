<template>
    <div class="home">
        <img alt="Vue logo" src="../assets/HappyHouseLogo_MJNH.jpg" />
        <div class="col-md-6">
            <input
                type="text"
                v-model="HouseKeyword"
                placeholder="원하시는 지역명, 아파트명을 입력해주세요"
                style="width:50%"
            />
            <button @click="HouseSearch">검색</button>
            <div>
                <span v-for="(result, index) in HouseSearchResult" :key="index">
                    {{ result }}<br />
                </span>
            </div>
        </div>
    </div>
</template>

<script>
// @ is an alias to /src
import axios from 'axios';

export default {
    name: 'Home',
    components: {},
    data() {
        return {
            HouseKeyword: '',
            HouseSearchResult: '',
        };
    },
    methods: {
        HouseSearch() {
            axios
                .get('http://localhost/house/' + this.HouseKeyword)
                .then((response) => {
                    this.HouseSearchResult = response.data;
                    console.log('SUCCESS : ' + response.data.length);
                })
                .catch((response) => {
                    console.log('FAIL : ' + response.status);
                });
        },
    },
};
</script>
