<template>
    <div>
        <img alt="Board logo" src="../assets/Board.png" />
        <h1>게시글 등록</h1>
        <div id="BoardInsertWrap">
            <table id="BoardInsert">
                <tr>
                    <th>제목</th>
                    <td colspan="3">
                        <input type="text" v-model="title" />
                    </td>
                </tr>
                <tr>
                    <th width="10%">작성자</th>
                    <td width="40%">
                        <input type="text" v-model="name" />
                    </td>
                    <th width="10%">비밀번호</th>
                    <td width="40%">
                        <input type="password" v-model="pass" />
                    </td>
                </tr>
                <tr>
                    <th>내용</th>
                    <td colspan="3">
                        <textarea v-model="content" />
                    </td>
                </tr>
            </table>
        </div>
        <div id="BoardButtonWrap">
            <button @click="insert">등록</button>
        </div>
    </div>
</template>

<script>
import axios from 'axios';
export default {
    data() {
        return {
            name: '',
            pass: '',
            title: '',
            content: '',
        };
    },
    methods: {
        list() {
            this.$router.push({ path: './', query: this.body });
        },
        insert() {
            axios
                .post('http://localhost/boards', {
                    num: '',
                    pass: this.pass,
                    name: this.name,
                    wdate: '',
                    title: this.title,
                    content: this.content,
                    count: 0,
                })
                .then((response) => {
                    console.log('SUCCESS : ' + response);
                    alert('새로운 게시글이 등록되었습니다!');
                    this.$router.push({
                        path: './BoardHome',
                        query: this.body,
                    });
                })
                .catch((response) => {
                    console.log('FAIL : ' + response.status);
                });
        },
    },
};
</script>

<style scoped>
#BoardInsert {
    border-top: 1px solid #888;
    margin: auto;
    margin-bottom: 50px;
    width: 80%;
}
#BoardInsert th,
#BoardInsert td {
    border-bottom: 1px solid #eee;
    padding: 5px 0;
}
#BoardInsert td {
    padding: 10px 10px;
    box-sizing: border-box;
}
#BoardInsert td input {
    width: 100%;
    min-height: 30px;
    box-sizing: border-box;
    padding: 0 10px;
}
#BoardInsert td textarea {
    width: 100%;
    min-height: 300px;
    padding: 10px;
    box-sizing: border-box;
}
#BoardButtonWrap {
    text-align: center;
}
</style>
