<template>
    <footer class="footer" :class="{ [`footer-${type}`]: type }" :data-background-color="backgroundColor">
        <div class="container">
            <nav>
                <ul>
                    <li>
                        <a href="https://www.ssafy.com">
                            SSAFY 4TH SEOUL
                        </a>
                    </li>
                </ul>
            </nav>
            <div class="copyright">
                &copy; {{ year }}, Designed by <a href="mailto:minjin0121@gmail.com" target="_blank" rel="noopener">MINJIN</a> &
                <a href="mailto:nahyunee24@naver.com" target="_blank" rel="noopener">NAHYUN</a>
            </div>
        </div>
    </footer>
</template>
<script>
export default {
    props: {
        backgroundColor: String,
        type: String,
    },
    data() {
        return {
            year: new Date().getFullYear(),
        };
    },
};
</script>
<style></style>
