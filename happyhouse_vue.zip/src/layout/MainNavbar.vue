<template>
  <navbar
    position="fixed"
    type="default"
    :transparent="transparent"
    :color-on-scroll="colorOnScroll"
    menu-classes="ml-auto"
  >
    <template>
      <router-link v-popover:popover1 class="navbar-brand" to="/">
        HAPPY HOUSE
      </router-link>
    </template>
    <template slot="navbar-menu">
      <!-- <p v-show="this.$session.get('userID') != ''">
                {{ this.$session.get('userID') }} 님, 환영합니다!
            </p> -->
      <li
        tag="li"
        class="nav-item"
        v-show="this.$session.get('userID') != ''"
        style="padding: 10px;"
      >
        {{ this.$session.get('userID') }} 님, 환영합니다!
      </li>
      <li class="nav-item" v-show="this.$session.get('userID') != ''">
        <a
          class="nav-link"
          rel="tooltip"
          title="Logout"
          data-placement="bottom"
          href="/logout"
        >
          <i class="now-ui-icons emoticons_satisfied"></i>
          <p class="d-lg-none d-xl-none">Logout</p>
        </a>
      </li>

      <drop-down tag="li" title="Menu" class="nav-item">
        <nav-link to="/house">
          <i class="now-ui-icons education_paper"></i> House
        </nav-link>
        <nav-link to="/board">
          <i class="now-ui-icons files_paper"></i> Q & A
        </nav-link>
        <!-- session에 id data가 있을 때만 보이게 해둠 -->
        <nav-link to="/profile" v-show="this.$session.get('userID') != ''">
          <i class="now-ui-icons users_single-02"></i> Profile
        </nav-link>
        <!-- <nav-link
                    to="/login"
                    v-show="this.$session.get('userID') == ''"
                >
                    <i class="now-ui-icons users_single-02"></i> Login
                </nav-link>
                <nav-link
                    to="/logout"
                    v-show="this.$session.get('userID') != ''"
                >
                    <i class="now-ui-icons users_single-02"></i> Logout
                </nav-link>
                -->
      </drop-down>

      <li class="nav-item" v-show="this.$session.get('userID') == ''">
        <a
          class="nav-link"
          rel="tooltip"
          title="Login"
          data-placement="bottom"
          href="/login"
        >
          <i class="now-ui-icons users_single-02"></i>
          <p class="d-lg-none d-xl-none">Login</p>
        </a>
      </li>
    </template>
  </navbar>
</template>

<script>
import { DropDown, Navbar, NavLink } from '@/components';
import { Popover } from 'element-ui';
export default {
  name: 'main-navbar',
  props: {
    transparent: Boolean,
    colorOnScroll: Number,
  },
  components: {
    DropDown,
    Navbar,
    NavLink,
    [Popover.name]: Popover,
  },
};
</script>

<style scoped></style>
