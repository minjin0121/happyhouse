<template>
  <navbar
    position="fixed"
    type="primary"
    :transparent="transparent"
    :color-on-scroll="colorOnScroll"
    menu-classes="ml-auto"
  >
    <template>
      <router-link v-popover:popover1 class="navbar-brand" to="/main">
        HAPPY HOUSE
      </router-link>
    </template>
    <template slot="navbar-menu">
      <drop-down tag="li" title="Menu" class="nav-item">
        <nav-link to="/house">
          <i class="now-ui-icons education_paper"></i> House
        </nav-link>
        <!-- session에 id data가 있을 때만 보이게 해둠 -->
        <nav-link to="/profile" v-show="this.$session.get('userID') != ''">
          <i class="now-ui-icons users_single-02"></i> Profile
        </nav-link>
        <nav-link to="/login" v-show="this.$session.get('userID') == ''">
          <i class="now-ui-icons users_circle-08"></i> Login
        </nav-link>
        <!-- @click="logout" 이 먼저 실행되길 바랐지만 to="/" 가 먼저 실행됨 -->
        <nav-link to="/logout" v-show="this.$session.get('userID') != ''">
          <i class="now-ui-icons users_circle-08"></i> Logout
        </nav-link>
      </drop-down>

      <li class="nav-item">
        <a
          class="nav-link"
          rel="tooltip"
          title="Follow us on Twitter"
          data-placement="bottom"
          href="/login"
        >
          <i class="now-ui-icons users_circle-08"></i>
          <p class="d-lg-none d-xl-none">Login</p>
        </a>
      </li>
    </template>
  </navbar>
</template>

<script>
import { DropDown, Navbar, NavLink } from '@/components';
import { Popover } from 'element-ui';
export default {
  name: 'main-navbar',
  props: {
    transparent: Boolean,
    colorOnScroll: Number,
  },
  components: {
    DropDown,
    Navbar,
    NavLink,
    [Popover.name]: Popover,
  },
};
</script>

<style scoped></style>
