import Vue from "vue";
import Router from "vue-router";
import Index from "./pages/Index.vue";
import Update from "./pages/Update.vue";
import House from "./pages/House.vue";
import Login from "./pages/Login.vue";
import Logout from "./pages/Logout.vue";
import Signin from "./pages/Signin.vue";
import Profile from "./pages/Profile.vue";
import MainNavbar from "./layout/MainNavbar.vue";
import MainFooter from "./layout/MainFooter.vue";

Vue.use(Router);

export default new Router({
    mode: "history",
    linkExactActiveClass: "active",
    routes: [
        {
            path: "/main",
            name: "index",
            components: { default: Index, header: MainNavbar, footer: MainFooter },
            props: {
                header: { colorOnScroll: 400 },
                footer: { backgroundColor: "black" },
            },
        },
        {
            path: "/house",
            name: "house",
            components: { default: House, header: MainNavbar, footer: MainFooter },
            props: {
                header: { colorOnScroll: 400 },
                footer: { backgroundColor: "black" },
            },
        },
        {
            path: "/login",
            name: "login",
            components: { default: Login, header: MainNavbar },
            props: {
                header: { colorOnScroll: 400 },
            },
        },
        {
            path: "/logout",
            name: "logout",
            components: { default: Logout, header: MainNavbar },
            props: {
                header: { colorOnScroll: 400 },
            },
        },
        {
            path: "/signin",
            name: "signin",
            components: { default: Signin, header: MainNavbar },
            props: {
                header: { colorOnScroll: 400 },
            },
        },
        {
            path: "/update",
            name: "update",
            components: { default: Update, header: MainNavbar },
            props: {
                header: { colorOnScroll: 400 },
            },
        },
        {
            path: "/profile",
            name: "profile",
            components: { default: Profile, header: MainNavbar, footer: MainFooter },
            props: {
                header: { colorOnScroll: 400 },
                footer: { backgroundColor: "black" },
            },
        },
    ],
    scrollBehavior: (to) => {
        if (to.hash) {
            return { selector: to.hash };
        } else {
            return { x: 0, y: 0 };
        }
    },
});


