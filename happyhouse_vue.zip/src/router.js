import Vue from "vue";
import Router from "vue-router";
import Index from "./pages/Index.vue";
import Update from "./pages/Update.vue";
import House from "./pages/House.vue";
import Login from "./pages/Login.vue";
import Logout from "./pages/Logout.vue";
import Signin from "./pages/Signin.vue";
import Profile from "./pages/Profile.vue";
import Board from "./pages/BoardHome.vue";
import BoardInsert from "./pages/BoardInsert.vue";
import BoardUpdate from "./pages/BoardUpdate.vue";
import MainNavbar from "./layout/MainNavbar.vue";
import MainFooter from "./layout/MainFooter.vue";

Vue.use(Router);

export default new Router({
    mode: "history",
    linkExactActiveClass: "active",
    routes: [
        {
            path: "/",
            name: "index",
            components: { default: Index, header: MainNavbar, footer: MainFooter },
            props: {
                header: { colorOnScroll: 280 },
                footer: { backgroundColor: "black" },
            },
        },
        {
            path: "/house",
            name: "house",
            components: { default: House, header: MainNavbar, footer: MainFooter },
            props: {
                header: { colorOnScroll: 280 },
                footer: { backgroundColor: "black" },
            },
        },
        {
            path: "/login",
            name: "login",
            components: { default: Login, header: MainNavbar },
            props: {
                header: { colorOnScroll: 280 },
                footer: { backgroundColor: "black" },
            },
        },
        {
            path: "/logout",
            name: "logout",
            components: { default: Logout, header: MainNavbar },
            props: {
                header: { colorOnScroll: 280 },
                footer: { backgroundColor: "black" },
            },
        },
        {
            path: "/signin",
            name: "signin",
            components: { default: Signin, header: MainNavbar },
            props: {
                header: { colorOnScroll: 280 },
                footer: { backgroundColor: "black" },
            },
        },
        {
            path: "/update",
            name: "update",
            components: { default: Update, header: MainNavbar },
            props: {
                header: { colorOnScroll: 280 },
                footer: { backgroundColor: "black" },
            },
        },
        {
            path: "/profile",
            name: "profile",
            components: { default: Profile, header: MainNavbar, footer: MainFooter },
            props: {
                header: { colorOnScroll: 280 },
                footer: { backgroundColor: "black" },
            },
        },
        {
            path: "/board",
            name: "board",
            components: { default: Board, header: MainNavbar, footer: MainFooter },
            props: {
                header: { colorOnScroll: 280 },
                footer: { backgroundColor: "black" },
            },
        },{
            path: "/boardInsert",
            name: "boardInsert",
            components: { default: BoardInsert, header: MainNavbar, footer: MainFooter },
            props: {
                header: { colorOnScroll: 280 },
                footer: { backgroundColor: "black" },
            },
        },{
            path: "/boardUpdate",
            name: "boardUpdate",
            components: { default: BoardUpdate, header: MainNavbar, footer: MainFooter },
            props: {
                header: { colorOnScroll: 280 },
                footer: { backgroundColor: "black" },
            },
        },
    ],
    scrollBehavior: (to) => {
        if (to.hash) {
            return { selector: to.hash };
        } else {
            return { x: 0, y: 0 };
        }
    },
});


