<template>
  <div>
    <center>
      <h1>게시판 수정</h1>
      <div class="AddWrap">
        <form>
          <table class="tbAdd">
            <colgroup>
              <col width="15%" />
              <col width="*" />
            </colgroup>
            <tr>
              <th>제목</th>
              <td>
                <input type="text" v-model="title" style="width: 250%;" />
              </td>
            </tr>
            <tr>
              <th>작성자</th>
              <td>
                <input type="text" v-model="name" readonly />
              </td>
              <th>비밀번호</th>
              <td>
                <input type="password" v-model="pass" readonly />
              </td>
            </tr>
            <tr>
              <th>작성일</th>
              <td>
                <input type="text" v-model="wdate" readonly />
              </td>
              <th>조회수</th>
              <td>
                <input type="text" v-model="count" readonly />
              </td>
            </tr>
            <tr>
              <th>내용</th>
              <td><textarea v-model="content"></textarea></td>
            </tr>
          </table>
        </form>
      </div>

      <div class="btnWrap">
        <!-- <button @click="list" class="btn">목록</button>&nbsp;&nbsp; -->
        <button @click="update" class="btnAdd btn">수정</button>
      </div>
    </center>
  </div>
</template>

<script>
import axios from 'axios';
export default {
  data() {
    return {
      pass: '',
      name: '',
      wdate: '',
      title: '',
      content: '',
      count: '',
      num: 0,
    };
  },
  mounted() {
    console.log(this.$route.query.num);
    this.selectBoard(this.$route.query.num);
  },
  methods: {
    list() {
      this.$router.push({ path: './board', query: this.body });
    },
    selectBoard(num) {
      axios
        .get('http://localhost/boards/' + num)
        .then((res) => {
          console.log(res.data);
          this.title = res.data.title;
          this.content = res.data.content;
          this.num = res.data.num;
          this.pass = res.data.pass;
          this.name = res.data.name;
          this.count = res.data.count;
          this.wdate = res.data.wdate;
        })
        .catch((err) => {
          console.log('>>>' + err);
        });
    },
    update() {
      axios
        .put('http://localhost/boards', {
          title: this.title,
          content: this.content,
          num: this.num,
          pass: this.pass,
          name: this.name,
          count: this.count,
          wdate: this.wdate,
        })
        .then((res) => {
          console.log(res);
          alert('게시글이 수정되었습니다!');
          this.list();
        })
        .catch((err) => {
          console.log('>>>' + err);
        });
    },
  },
};
</script>

<style scoped>
.tbAdd {
  border-top: 1px solid #888;
}
.tbAdd th,
.tbAdd td {
  border-bottom: 1px solid #eee;
  padding: 5px 0;
}
.tbAdd td {
  padding: 10px 10px;
  box-sizing: border-box;
}
.tbAdd td input {
  width: 100%;
  min-height: 30px;
  box-sizing: border-box;
  padding: 0 10px;
}
.tbAdd td textarea {
  width: 250%;
  min-height: 300px;
  padding: 10px;
  box-sizing: border-box;
}
.btnWrap {
  text-align: center;
  margin: 20px 0 0 0;
}
.btnWrap a {
  margin: 0 10px;
}
.btnAdd {
  background: #43b984;
}
.btnDelete {
  background: #f00;
}
</style>
