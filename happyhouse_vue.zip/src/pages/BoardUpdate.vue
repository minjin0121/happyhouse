<template>
  <div>
    <div class="page-header page-header-small">
      <parallax
        class="page-header-image"
        style="background-image: url('img/bg2.jpg');"
      >
      </parallax>
      <div class="content-center">
        <div class="container">
          <h1 class="title">Q & A</h1>
          <h5>무엇이든 물어보세요!</h5>
          <div class="text-center"></div>
        </div>
      </div>
    </div>
    <center>
      <div class="section" style="margin-left:-10%;">
        <form>
          <table class="tbAdd">
            <colgroup>
              <col width="15%" />
              <col width="*" />
            </colgroup>
            <tr>
              <th>제목</th>
              <td>
                <input type="text" v-model="title" style="width: 250%;" />
              </td>
            </tr>
            <tr>
              <th>작성자</th>
              <td>
                <h6 v-text="name"></h6>
              </td>
            </tr>
            <tr>
              <th>작성일</th>
              <td>
                <h6 v-text="wdate"></h6>
              </td>
              <th>조회수</th>
              <td>
                <h6 v-text="count"></h6>
              </td>
            </tr>
            <tr>
              <th>내용</th>
              <td><textarea v-model="content"></textarea></td>
            </tr>
          </table>
        </form>
      </div>

      <div class="btnWrap">
        <n-button n-button type="default" round size="lg" @click="update">
          수정하기
        </n-button>
      </div>
    </center>
  </div>
</template>

<script>
import axios from 'axios';
import { Button } from '@/components';
export default {
  components: {
    [Button.name]: Button,
  },
  data() {
    return {
      pass: '',
      name: '',
      wdate: '',
      title: '',
      content: '',
      count: '',
      num: 0,
    };
  },
  mounted() {
    console.log(this.$route.query.num);
    this.selectBoard(this.$route.query.num);
  },
  methods: {
    list() {
      this.$router.push({ path: './board', query: this.body });
    },
    selectBoard(num) {
      axios
        .get('http://localhost/boards/' + num)
        .then((res) => {
          console.log(res.data);
          this.title = res.data.title;
          this.content = res.data.content;
          this.num = res.data.num;
          this.pass = res.data.pass;
          this.name = res.data.name;
          this.count = res.data.count;
          this.wdate = res.data.wdate;
        })
        .catch((err) => {
          console.log('>>>' + err);
        });
    },
    update() {
      axios
        .put('http://localhost/boards', {
          title: this.title,
          content: this.content,
          num: this.num,
          pass: this.pass,
          name: this.name,
          count: this.count,
          wdate: this.wdate,
        })
        .then((res) => {
          console.log(res);
          alert('게시글이 수정되었습니다!');
          this.list();
        })
        .catch((err) => {
          console.log('>>>' + err);
        });
    },
  },
};
</script>

<style scoped>
.tbAdd {
  border-top: 1px solid #888;
}
.tbAdd th,
.tbAdd td {
  border-bottom: 1px solid #eee;
  padding: 5px 0;
}
.tbAdd td {
  padding: 10px 10px;
  box-sizing: border-box;
}
.tbAdd td input {
  width: 100%;
  min-height: 30px;
  box-sizing: border-box;
  padding: 0 10px;
}
.tbAdd td textarea {
  width: 250%;
  min-height: 300px;
  padding: 10px;
  box-sizing: border-box;
}
.btnWrap {
  text-align: center;
  margin: 20px 0 0 0;
}
.btnWrap a {
  margin: 0 10px;
}
.btnAdd {
  background: #43b984;
}
.btnDelete {
  background: #f00;
}
</style>
