<template>
  <div>
    <div class="page-header clear-filter" filter-color="orange">
      <parallax
        class="page-header-image"
        style="background-image:url('img/bg5.jpg')"
      >
      </parallax>
      <div class="container">
        <div class="photo-container">
          <img src="img/eva.jpg" alt="" />
        </div>
        <h3 class="title" :name="name">
          {{ name }}
          <i class="now-ui-icons ui-1_settings-gear-63" @click="update()"></i>
        </h3>

        <p class="category" :addr="addr">{{ addr }}</p>
        <div class="content" style="width=600px;">
          <center>
            <p>선호지역</p>
            <table>
              <tr v-for="p in preferList" :key="p">
                <td>
                  <a :href="'/house?type=dong&code=' + p.code">{{ p.addr }}</a>
                </td>
                <td>
                  <i
                    class="now-ui-icons design_scissors"
                    @click="removePrefer(p.code)"
                  ></i>
                </td>
              </tr>
            </table>

            <div class="card-footer text-center">
              <n-button type="primary" @click.native="modals.classic = true">
                추가하기
              </n-button>
            </div>
          </center>
        </div>
      </div>
    </div>
    <div class="section">
      <div class="container">
        <div class="row">
          <div class="col-md-6 ml-auto mr-auto">
            <h4 class="title text-center">My Portfolio</h4>
          </div>
          <tabs
            pills
            class="nav-align-center"
            tab-content-classes="gallery"
            tab-nav-classes="nav-pills-just-icons"
            type="primary"
          >
            <tab-pane title="Profile">
              <i slot="label" class="now-ui-icons design_image"></i>

              <div class="col-md-10 ml-auto mr-auto">
                <div class="row collections">
                  <div class="col-md-6">
                    <img src="img/bg6.jpg" class="img-raised" />
                    <img src="img/bg11.jpg" alt="" class="img-raised" />
                  </div>
                  <div class="col-md-6">
                    <img src="img/bg7.jpg" alt="" class="img-raised" />
                    <img src="img/bg8.jpg" alt="" class="img-raised" />
                  </div>
                </div>
              </div>
            </tab-pane>

            <tab-pane title="Home">
              <i slot="label" class="now-ui-icons location_world"></i>

              <div class="col-md-10 ml-auto mr-auto">
                <div class="row collections">
                  <div class="col-md-6">
                    <img src="img/bg1.jpg" alt="" class="img-raised" />
                    <img src="img/bg3.jpg" alt="" class="img-raised" />
                  </div>
                  <div class="col-md-6">
                    <img src="img/bg8.jpg" alt="" class="img-raised" />
                    <img src="img/bg7.jpg" alt="" class="img-raised" />
                  </div>
                </div>
              </div>
            </tab-pane>

            <tab-pane title="Messages">
              <i slot="label" class="now-ui-icons sport_user-run"></i>

              <div class="col-md-10 ml-auto mr-auto">
                <div class="row collections">
                  <div class="col-md-6">
                    <img src="img/bg3.jpg" alt="" class="img-raised" />
                    <img src="img/bg8.jpg" alt="" class="img-raised" />
                  </div>
                  <div class="col-md-6">
                    <img src="img/bg7.jpg" alt="" class="img-raised" />
                    <img src="img/bg6.jpg" class="img-raised" />
                  </div>
                </div>
              </div>
            </tab-pane>
          </tabs>
        </div>
      </div>
    </div>
    <div>
      <modal :show.sync="modals.classic" headerClasses="justify-content-center">
        <h4 slot="header" class="title title-up">선호지역 추가</h4>

        <center>
          <select v-model="selectedSido" @change="getGugun(value)">
            <option v-for="s in sidoList" :key="s" :value="s.sidoCode">{{
              s.sidoName
            }}</option>
          </select>

          <select v-model="selectedGugun" @change="getDong()">
            <option v-for="g in gugunList" :key="g" :value="g.gugunCode">{{
              g.gugunName
            }}</option>
          </select>

          <select v-model="selectedDong" @change="getAddr()">
            <option v-for="d in dongList" :key="d" :value="d.gugunName">{{
              d.gugunName
            }}</option>
          </select>
        </center>

        <template slot="footer">
          <n-button type="danger" @click="addPrefer()">추가하기</n-button>
        </template>
      </modal>
    </div>
  </div>
</template>
<script>
import { Tabs, TabPane, Card, FormGroupInput, Button } from '@/components';
import { Modal } from '@/components';
import axios from 'axios';

export default {
  name: 'profile',
  bodyClass: 'profile-page',
  components: {
    Modal,
    Tabs,
    TabPane,
    [Button.name]: Button,
    [FormGroupInput.name]: FormGroupInput,
  },
  data() {
    return {
      modals: {
        classic: false,
      },
      name: '',
      addr: '',
      sidoList: [],
      gugunList: [],
      dongList: [],
      preferList: [],
      selectedSido: '',
      selectedGugun: '',
      selectedDong: '',
      selectedAddr: '',
      selectedCode: '',
    };
  },
  mounted() {
    var id = this.$session.get('userID');
    axios
      .get('http://localhost/member/info/' + id)
      .then((response) => {
        console.log(response);
        this.name = response.data.memberNAME;
        this.addr = response.data.memberADDR;
      })
      .catch((error) => {
        console.log(error);
      });
    axios
      .get('http://localhost/prefer/' + id)
      .then((response) => {
        console.log(response);
        this.preferList = response.data;
      })
      .catch((error) => {
        console.log(error);
      });
    this.getSido();
  },
  methods: {
    getSido() {
      axios
        .get('http://localhost/sido')
        .then((response) => {
          //console.log(response.data);
          this.sidoList = response.data;
        })
        .catch((error) => {
          console.log(error);
        });
    },
    update() {
      this.$router.push({ path: './update' });
    },
    getGugun() {
      axios
        .get('http://localhost/gugun/' + this.selectedSido)
        .then((response) => {
          //console.log(response.data);
          this.gugunList = response.data;
        })
        .catch((error) => {
          console.log(error);
        });
    },
    getDong(code) {
      this.gugun = code;
      console.log(this.sido, this.gugun, this.dong);
      axios
        .get('http://localhost/dong/' + this.selectedGugun)
        .then((response) => {
          //console.log(response.data);
          this.dongList = response.data;
        })
        .catch((error) => {
          console.log(error);
        });
    },
    addPrefer() {
      console.log(this.selectedSido, this.selectedGugun, this.selectedDong);
      axios
        .post('http://localhost/makeAddr', {
          code: this.selectedGugun,
          dong: this.selectedDong,
        })
        .then((response) => {
          console.log(response.data);
          this.selectedAddr = response.data.dong;
          this.selectedCode = response.data.code;
          axios
            .post('http://localhost/prefer/insert', {
              id: this.$session.get('userID'),
              code: this.selectedCode,
              addr: this.selectedAddr,
            })
            .then((response) => {
              //console.log(response.data);
              alert('관심 지역이 추가되었습니다!');
              this.modals.classic = false;
              this.$router.push({ path: './profile' });
            })
            .catch((error) => {
              console.log(error);
            });
        })
        .catch((error) => {
          console.log(error);
        });
    },
    removePrefer(code) {
      var id = this.$session.get('userID');
      console.log(id, code);
      axios
        .get('http://localhost/prefer/delete/' + id + '/' + code)
        .then((response) => {
          console.log(response.data);
          alert('관심 지역이 삭제되었습니다!');
          this.modals.classic = false;
          this.$router.push({ path: './profile' });
        })
        .catch((error) => {
          console.log(error);
        });
    },
  },
};
</script>
<style></style>
