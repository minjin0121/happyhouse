<template>
  <div>
    <center>
      <h1>게시판 등록</h1>
      <div class="AddWrap">
        <form>
          <table class="tbAdd">
            <colgroup>
              <col width="15%" />
              <col width="*" />
            </colgroup>
            <tr>
              <th>제목</th>
              <td>
                <input type="text" v-model="title" style="width: 250%;" />
              </td>
            </tr>
            <tr>
              <th>작성자</th>
              <td><input type="text" v-model="name" /></td>
              <th>비밀번호</th>
              <td><input type="password" v-model="pass" /></td>
            </tr>
            <tr>
              <th>내용</th>
              <td><textarea v-model="content"></textarea></td>
            </tr>
          </table>
        </form>
      </div>

      <div class="btnWrap">
        <!-- <button @click="list" class="btn">목록</button>&nbsp;&nbsp; -->
        <button @click="insert" class="btnAdd btn">등록</button>
      </div>
    </center>
  </div>
</template>

<script>
import axios from 'axios';
export default {
  data() {
    //변수 생성
    return {
      num: '',
      pass: '',
      name: '',
      wdate: '',
      title: '',
      content: '',
      count: 0,
    };
  },
  methods: {
    list() {
      //리스트 화면으로 이동 함수
      this.$router.push({ path: './BoardHome', query: this.body });
    },
    insert() {
      axios // 비동기 요청하기
        .post('http://localhost/boards', {
          num: '',
          pass: this.pass,
          name: this.name,
          wdate: '',
          title: this.title,
          content: this.content,
          count: 0,
        })
        .then((response) => {
          console.log('SUCCESS : ' + response);
          alert('새로운 게시글이 등록되었습니다!');
          this.$router.push({ path: './board', query: this.body });
        })
        .catch((response) => {
          console.log('FAIL : ' + response.status);
        });
    },
  },
};
</script>

<style scoped>
.tbAdd {
  border-top: 1px solid #888;
}
.tbAdd th,
.tbAdd td {
  border-bottom: 1px solid #eee;
  padding: 5px 0;
}
.tbAdd td {
  padding: 10px 10px;
  box-sizing: border-box;
}
.tbAdd td input {
  width: 100%;
  min-height: 30px;
  box-sizing: border-box;
  padding: 0 10px;
}
.tbAdd td textarea {
  width: 250%;
  min-height: 300px;
  padding: 10px;
  box-sizing: border-box;
}
.btnWrap {
  text-align: center;
  margin: 20px 0 0 0;
}
.btnWrap a {
  margin: 0 10px;
}
.btnAdd {
  background: #43b984;
}
.btnDelete {
  background: #f00;
}
</style>
