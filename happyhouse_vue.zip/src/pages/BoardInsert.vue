<template>
  <div>
    <div class="page-header page-header-small">
      <parallax
        class="page-header-image"
        style="background-image: url('img/bg2.jpg');"
      >
      </parallax>
      <div class="content-center">
        <div class="container">
          <h1 class="title">Q & A</h1>
          <h5>무엇이든 물어보세요!</h5>
          <div class="text-center"></div>
        </div>
      </div>
    </div>
    <center>
      <div class="section">
        <form>
          <table class="tbAdd">
            <colgroup>
              <col width="15%" />
              <col width="*" />
            </colgroup>
            <tr>
              <th>제목</th>
              <td>
                <input type="text" v-model="title" style="width: 250%;" />
              </td>
            </tr>
            <tr>
              <th>작성자</th>
              <td><input type="text" v-model="name" /></td>
              <th>비밀번호</th>
              <td><input type="password" v-model="pass" /></td>
            </tr>
            <tr>
              <th>내용</th>
              <td><textarea v-model="content"></textarea></td>
            </tr>
          </table>
        </form>
      </div>

      <div class="btnWrap">
        <n-button n-button type="default" round size="lg" @click="insert">
          등록하기
        </n-button>
      </div>
    </center>
  </div>
</template>

<script>
import axios from 'axios';
import { Button } from '@/components';
export default {
  components: {
    [Button.name]: Button,
  },
  data() {
    //변수 생성
    return {
      num: '',
      pass: '',
      name: '',
      wdate: '',
      title: '',
      content: '',
      count: 0,
    };
  },
  methods: {
    list() {
      //리스트 화면으로 이동 함수
      this.$router.push({ path: './BoardHome', query: this.body });
    },
    insert() {
      axios // 비동기 요청하기
        .post('http://localhost/boards', {
          num: '',
          pass: this.pass,
          name: this.name,
          wdate: '',
          title: this.title,
          content: this.content,
          count: 0,
        })
        .then((response) => {
          console.log('SUCCESS : ' + response);
          alert('새로운 게시글이 등록되었습니다!');
          this.$router.push({ path: './board', query: this.body });
        })
        .catch((response) => {
          console.log('FAIL : ' + response.status);
        });
    },
  },
};
</script>

<style scoped>
.tbAdd {
  border-top: 1px solid #888;
}
.tbAdd th,
.tbAdd td {
  border-bottom: 1px solid #eee;
  padding: 5px 0;
}
.tbAdd td {
  padding: 10px 10px;
  box-sizing: border-box;
}
.tbAdd td input {
  width: 100%;
  min-height: 30px;
  box-sizing: border-box;
  padding: 0 10px;
}
.tbAdd td textarea {
  width: 250%;
  min-height: 300px;
  padding: 10px;
  box-sizing: border-box;
}
.btnWrap {
  text-align: center;
  margin: -10px 0 20px 0;
}
.btnWrap a {
  margin: 0 10px;
}
.btnAdd {
  background: #43b984;
}
.btnDelete {
  background: #f00;
}
</style>
