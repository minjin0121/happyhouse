<template>
  <div>
    <div class="page-header clear-filter" filter-color="orange">
      <parallax
        class="page-header-image"
        style="background-image: url('img/header.jpg')"
      >
      </parallax>
      <div class="container">
        <div class="brand">
          <img class="n-logo" src="img/now-logo.png" alt="" />
          <h1 class="h1-seo">HAPPY HOUSE</h1>
        </div>
        <div class="row" style="margin-top: 50px">
          <fg-input
            @keyup="HouseSearch"
            v-model="HouseSearchKeyword"
            addon-left-icon="now-ui-icons ui-1_zoom-bold"
            placeholder="원하는 지역명(동명), 단지명(아파트명)을 입력해주세요"
          ></fg-input>
        </div>
        <center>
          <div
            style="background-color: white; width: 750px"
            v-if="HouseSearchResult.length > 1"
          >
            <table style="width: 700px">
              <tr
                v-for="(result, index) in HouseSearchResult"
                :key="index"
                @click="HouseDetail(result)"
              >
                <td style="width: 30px">
                  <i
                    v-if="result.type == 'dong'"
                    class="now-ui-icons location_pin"
                  ></i>
                  <i
                    v-else-if="result.type == 'apt'"
                    class="now-ui-icons shopping_shop"
                  ></i>
                </td>
                <td style="width: 300px">{{ result.aptName }}</td>
                <td style="text-align: right">{{ result.addr }}</td>
              </tr>
            </table>
          </div>
        </center>
      </div>
    </div>
  </div>
</template>
<script>
import { Parallax, FormGroupInput } from '@/components';
import axios from 'axios';

export default {
  name: 'index',
  bodyClass: 'index-page',
  components: {
    Parallax,
    [FormGroupInput.name]: FormGroupInput,
  },
  data() {
    return {
      HouseSearchKeyword: '',
      HouseSearchResult: [
        {
          aptName: '',
          addr: '',
          type: '',
          code: '',
          no: '',
        },
      ],
      src: '',
    };
  },
  methods: {
    HouseSearch() {
      console.log('HouseSearch : ' + this.HouseSearchKeyword);
      axios
        .get('http://localhost/list/' + this.HouseSearchKeyword)
        .then((response) => {
          this.HouseSearchResult = [];
          for (let i = 0; i < response.data.length; i++) {
            if (response.data[i] == 'apt') {
              this.HouseSearchResult.push({
                type: response.data[i++],
                code: response.data[i++],
                aptName: response.data[i++],
                addr: response.data[i++],
                no: response.data[i],
              });
            } else if (response.data[i] == 'dong') {
              this.HouseSearchResult.push({
                type: response.data[i++],
                code: response.data[i++],
                aptName: response.data[i],
              });
            }
          }
          console.log('SUCCESS : ' + response.data);
        })
        .catch((response) => {
          console.log('FAIL : ' + response.status);
        });
    },
    HouseDetail(result) {
      console.log(result);
      if (result.type == 'dong') {
        this.$router.push({
          path: './house',
          query: { type: result.type, code: result.code },
        });
      } else if (result.type == 'apt') {
        this.$router.push({
          path: './house',
          query: { type: result.type, code: result.code, no: result.no },
        });
      }
    },
  },
};
</script>
<style>
.resultDiv {
  background-color: white;
  height: 300px;
}
.resultDiv::-webkit-scrollbar {
  width: 10px;
  background-color: black;
}
table {
  background-color: white;
  color: black;
  margin: 20px;
}
</style>
