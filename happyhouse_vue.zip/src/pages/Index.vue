<template>
  <div>
    <div class="page-header clear-filter" filter-color="orange">
      <parallax
        class="page-header-image"
        style="background-image: url('img/header.jpg')"
      >
      </parallax>
      <div class="container">
        <div class="brand">
          <img class="n-logo" src="img/now-logo.png" alt="" />
          <h1 class="h1-seo">HAPPY HOUSE</h1>
        </div>
        <div id="Search" class="row">
          <fg-input
            @keyup="HouseSearch"
            @keyup.enter="HouseSearchEnter"
            v-model="HouseSearchKeyword"
            addon-left-icon="now-ui-icons ui-1_zoom-bold"
            placeholder="원하는 지역명(동명), 단지명(아파트명)을 입력해주세요"
          ></fg-input>
        </div>
        <div id="resultDiv" v-if="HouseSearchResult.length > 0">
          <table id="resultTable">
            <tr
              v-for="(result, index) in HouseSearchResult"
              :key="index"
              @click="HouseDetail(result)"
            >
              <td style="width: 7%; text-align:left">
                <i
                  v-if="result.type == 'dong'"
                  class="now-ui-icons location_pin"
                ></i>
                <i
                  v-else-if="result.type == 'apt'"
                  class="now-ui-icons shopping_shop"
                ></i>
              </td>
              <td style="width: 70%; text-align:left">
                {{ result.aptName }}
              </td>
              <td style="text-align: right; font-size: 80%;">
                {{ result.addr }}
              </td>
            </tr>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { Parallax, FormGroupInput } from '@/components';
import axios from 'axios';

export default {
  name: 'index',
  bodyClass: 'index-page',
  components: {
    Parallax,
    [FormGroupInput.name]: FormGroupInput,
  },
  data() {
    return {
      HouseSearchKeyword: '',
      HouseSearchResult: '',
      src: '',
    };
  },
  methods: {
    HouseSearch() {
      console.log('HouseSearch : ' + this.HouseSearchKeyword);
      axios
        .get('http://localhost/list/' + this.HouseSearchKeyword)
        .then((response) => {
          this.HouseSearchResult = [];
          for (let i = 0; i < response.data.length; i++) {
            if (response.data[i] == 'apt') {
              this.HouseSearchResult.push({
                type: response.data[i++],
                code: response.data[i++],
                aptName: response.data[i++],
                addr: response.data[i++],
                no: response.data[i],
              });
            } else if (response.data[i] == 'dong') {
              this.HouseSearchResult.push({
                type: response.data[i++],
                code: response.data[i++],
                aptName: response.data[i++],
                addr: response.data[i],
              });
            }
          }
          console.log(
            'SUCCESS (' + this.HouseSearchResult.length + ') : ' + response.data
          );
        })
        .catch((response) => {
          console.log(
            'FAIL (' + this.HouseSearchResult.length + ') : ' + response.status
          );
          this.HouseSearchResult = '';
        });
    },
    HouseDetail(result) {
      console.log('HouseDetail : ' + result);
      if (result.type == 'dong') {
        this.$router.push({
          path: './house',
          query: { type: result.type, code: result.code },
        });
      } else if (result.type == 'apt') {
        this.$router.push({
          path: './house',
          query: {
            type: result.type,
            code: result.code,
            no: result.no,
          },
        });
      }
    },
    HouseSearchEnter() {
      console.log('HouseSearchEnter : ' + this.HouseSearchResult[0].type);
      this.HouseDetail(this.HouseSearchResult[0]);
    },
  },
  created() {
    console.log('created : ' + this.HouseSearchResult.length);
  },
};
</script>
<style>
#Search {
  margin-top: 100px;
  width: 70%;
  margin: 0 auto;
}
#resultDiv {
  background-color: white;
  width: 65%;
  padding: 3px;
  margin: 0 auto;
}
#resultTable {
  background-color: white;
  color: black;
  margin: 20px;
}
#resultTable tr {
  border-bottom: 7px solid white;
}
</style>
