<template>
  <div>
    <div class="page-header page-header-small">
      <parallax
        class="page-header-image"
        style="background-image: url('img/bg6.jpg');"
      >
      </parallax>
      <div class="content-center">
        <div class="container">
          <h1 class="title">QnA</h1>
          <div class="text-center"></div>
        </div>
      </div>
    </div>
    <div id="BoardDetail">
      <center>
        <div id="BoardDetailWrap" class="section">
          <table id="BoardDetail">
            <!-- <colgroup>
                    <col width="15%" />
                    <col width="*" />
                </colgroup> -->
            <tr>
              <th width="10%">번호</th>
              <td width="40%">{{ board.num }}</td>
              <th width="10%">작성자</th>
              <td width="40%">{{ board.name }}</td>
            </tr>
            <tr>
              <th>조회수</th>
              <td>{{ board.count }}</td>
              <th>작성일시</th>
              <td>{{ board.wdate }}</td>
            </tr>
            <tr>
              <th>제목</th>
              <td colspan="3">{{ board.title }}</td>
            </tr>
            <tr>
              <th>내용</th>
              <td colspan="3">{{ board.content }}</td>
            </tr>
          </table>

          <table id="BoardDetail">
            <tr v-show="board.answer != null">
              <th
                width="10%"
                style="color: blue; font-weight: bold; font-size:16px;"
              >
                답변
              </th>
              <td><p v-html="ans"></p></td>
            </tr>
          </table>
        </div>
        <div id="BoardButtonWrap">
          <n-button type="primary" @click="update">
            수정하기
          </n-button>
          <n-button type="primary" @click="remove">
            삭제하기
          </n-button>
          <!-- <button @click="update">수정</button>&nbsp;&nbsp;
          <button @click="remove">삭제</button> -->
        </div>
      </center>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import { Button, FormGroupInput } from '@/components';
export default {
  component: {
    [Button.name]: Button,
  },
  data() {
    return {
      board: '',
      ans: '',
      num: this.$route.query.num,
    };
  },
  mounted() {
    console.log('BOARDDETAIL : ' + this.num);
    this.selectOne();
  },
  methods: {
    selectOne() {
      axios
        .get('http://localhost/boards/' + this.num)
        .then((response) => {
          this.board = response.data;
          this.ans = this.board.answer;
          console.log('SUCCESS : ' + response.data.title);
        })
        .catch((response) => {
          console.log('FAIL : ' + response.status);
        });
    },
    update() {
      this.$router.push({
        path: './boardUpdate',
        query: { num: this.num },
      });
    },
    remove() {
      axios
        .delete('http://localhost/boards/' + this.num)
        .then((response) => {
          console.log('SUCCESS : ' + response);
          alert('게시글이 삭제되었습니다!');
          this.$router.push({ path: './board', query: this.body });
        })
        .catch((response) => {
          console.log('FAIL : ' + response.status);
        });
    },
  },
};
</script>

<style>
#BoardDetail {
  margin: auto;
  margin-bottom: 50px;
  width: 80%;
}
#BoardDetail th,
#BoardDetail td {
  border-bottom: 1px solid #eee;
  padding: 5px 0;
}
#BoardDetail td.txt_left {
  text-align: left;
}
</style>
