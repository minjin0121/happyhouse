<template>
  <div class="page-header clear-filter" filter-color="orange">
    <div
      class="page-header-image"
      style="background-image: url('img/login.jpg')"
    ></div>
    <div class="content">
      <div class="container">
        <div class="col-md-5 ml-auto mr-auto">
          <card type="login" plain>
            <div slot="header" class="logo-container">
              <img v-lazy="'img/now-logo.png'" alt="" />
            </div>

            <fg-input
              type="text"
              class="no-border input-lg"
              addon-left-icon="now-ui-icons users_circle-08"
              placeholder="ID"
              v-model="id"
            >
            </fg-input>

            <fg-input
              type="password"
              class="no-border input-lg"
              addon-left-icon="now-ui-icons text_caps-small"
              placeholder="Password"
              v-model="pass"
            >
            </fg-input>

            <template slot="raw-content">
              <div class="card-footer text-center">
                <a
                  href="#pablo"
                  class="btn btn-primary btn-round btn-lg btn-block"
                  @click="login()"
                  >Get Started
                </a>
              </div>
              <div class="pull-left">
                <h6>
                  <a href="/signin" class="link footer-link">Create Account</a>
                </h6>
              </div>
              <div class="pull-right">
                <h6>
                  <a href="/board" class="link footer-link">Need Help?</a>
                </h6>
              </div>
            </template>
          </card>
        </div>
      </div>
    </div>
    <main-footer></main-footer>
  </div>
</template>
<script>
import { Card, Button, FormGroupInput } from '@/components';
import MainFooter from '@/layout/MainFooter';
import axios from 'axios';
export default {
  name: 'login-page',
  bodyClass: 'login-page',
  components: {
    Card,
    MainFooter,
    [Button.name]: Button,
    [FormGroupInput.name]: FormGroupInput,
  },
  data() {
    return {
      id: '',
      pass: '',
    };
  },
  methods: {
    login() {
      console.log(this.id, this.pass);
      axios
        .post('http://localhost/member/login', {
          memberID: this.id,
          memberPW: this.pass,
          memberNAME: '',
          memberTEL: '',
          memberADDR: '',
        })
        .then((response) => {
          console.log(response);
          if (response.data == true) {
            this.$session.start();
            this.$session.set('userID', this.id);
            alert('환영합니다!' + this.$session.get('userID'));
            this.$router.push({
              path: '/',
            });
          } else {
            alert('ID와 비밀번호를 다시 입력해주세요.');
            (this.id = ''), (this.pass = '');
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
  },
};
</script>
<style></style>
