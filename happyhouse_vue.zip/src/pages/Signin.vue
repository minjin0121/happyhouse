<template>
  <div
    class="section section-signup"
    style="background-image: url('img/login.jpg'); background-size: cover; background-position: top center; min-height: 700px;"
  >
    <div class="container">
      <div class="row">
        <card class="card-signup" header-classes="text-center" color="black">
          <template slot="header">
            <h3 class="card-title title-up">Sign Up</h3>
          </template>
          <template>
            <!-- id, 중복확인 버튼을 한 줄에 넣고싶지만 안 되는 중 -->
            <div style="display :inline;">
              <fg-input
                type="text"
                class="no-border"
                placeholder="ID"
                addon-left-icon="now-ui-icons users_circle-08"
                v-model="id"
              >
              </fg-input>
              <n-button
                type="default"
                round
                size="small"
                @click="confirmId()"
                style="margin-left:33%;"
                >중복 확인</n-button
              >
            </div>
            <center><p v-html="resultId"></p></center>

            <!-- id 사용가능 여부 나오는 곳 -->

            <fg-input
              type="password"
              class="no-border"
              placeholder="비밀번호"
              addon-left-icon="now-ui-icons objects_key-25"
              v-model="pass"
            >
            </fg-input>

            <fg-input
              type="password"
              class="no-border"
              placeholder="비밀번호 확인"
              addon-left-icon="now-ui-icons objects_key-25"
              v-model="pass0"
              @keyup="confirmPass"
            >
            </fg-input>
            <center>
              <p v-html="resultPass"></p>
            </center>

            <!-- 비밀번호 일치 여부 나오는 곳 -->

            <fg-input
              type="text"
              class="no-border"
              placeholder="닉네임"
              addon-left-icon="now-ui-icons users_single-02"
              v-model="name"
            >
            </fg-input>

            <fg-input
              type="text"
              class="no-border"
              placeholder="주소"
              addon-left-icon="now-ui-icons location_pin"
              v-model="addr"
            >
            </fg-input>

            <fg-input
              type="tel"
              class="no-border"
              placeholder="전화번호"
              addon-left-icon="now-ui-icons tech_mobile"
              v-model="tel"
            >
            </fg-input>
          </template>
          <div class="card-footer text-center">
            <n-button type="default" round size="lg" @click="signin()">
              SIGN IN
            </n-button>
          </div>
        </card>
      </div>
    </div>
  </div>
</template>
<script>
import { Card, FormGroupInput, Button } from '@/components';
import axios from 'axios';

export default {
  components: {
    Card,
    [Button.name]: Button,
    [FormGroupInput.name]: FormGroupInput,
  },
  data() {
    return {
      id: '',
      pass: '',
      pass0: '', // 비밀번호 재차 확인을 위한 data
      addr: '',
      name: '',
      tel: '',
      resultId: '', // id 사용가능 여부
      resultPass: '', // pw 일치 여부
    };
  },
  methods: {
    // 회원가입
    signin() {
      if (this.resultPass != '' || this.resultId != '') {
        alert('ID와 비밀번호를 확인해주세요.');
        return;
      }
      axios
        .post('http://localhost/member/signin', {
          memberID: this.id,
          memberPW: this.pass,
          memberNAME: this.name,
          memberTEL: this.tel,
          memberADDR: this.addr,
        })
        .then((response) => {
          console.log(response);
          // STS 에서 return type을 boolean으로 받아 성공/실패 여부를 받음
          if (response.data == true) {
            this.$session.start();
            this.$session.set('userID', this.id);
            alert('Happy House에 오신 것을 환영합니다!');
            this.$router.push({
              path: '/',
            });
          } else {
            alert('회원가입에 실패했습니다. 다시 시도해주세요.');
            (this.id = ''),
              (this.pass = ''),
              (this.pass0 = ''),
              (this.tel = ''),
              (this.addr = ''),
              (this.name = '');
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    // 비밀번호 일치 여부
    confirmPass() {
      if (this.pass != this.pass0) {
        this.resultPass = '비밀번호가 일치하지 않습니다.';
      } else {
        this.resultPass = '';
      }
    },
    // id 사용가능 여부
    confirmId() {
      axios
        .post('http://localhost/member/signin/' + this.id)
        .then((response) => {
          console.log(response);
          // 해당 id를 가진 data 개수를 return 하므로 이미 있는 id일 때는 1, 없을 때는 0
          if (response.data == 1) {
            this.resultId = '이미 존재하는 ID입니다.';
            this.id = '';
          } else {
            alert('사용 가능한 ID입니다.');
            this.resultId = '';
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
  },
};
</script>
<style></style>
