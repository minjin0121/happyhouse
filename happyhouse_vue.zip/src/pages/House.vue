<template>
  <div>
    <div class="page-header page-header-small">
      <parallax
        class="page-header-image"
        style="background-image: url('img/bg6.jpg');"
      >
      </parallax>
      <div class="content-center">
        <div class="container">
          <h1 class="title">This is Happy House.</h1>
          <div class="text-center"></div>
        </div>
      </div>
    </div>
    <div class="section">
      <div id="map-canvas" class="map-canvas" style="height: 600px;"></div>
      <div id="map-info">
        <i class="now-ui-icons ui-1_simple-remove" @click="mapInfoClose"></i>
        <p id="Info_aptName">{{ housedeal }}</p>
        <div id="Info_deal"></div>
        <ul class="elements">
          <li id="Info_dealAmount"></li>
          <li id="Info_dealDate"></li>
          <li id="Info_area"></li>
          <li id="Info_floor"></li>
        </ul>
        <!-- <table>
                    <tr>
                        <th>거래금액</th>
                        <th>거래일</th>
                        <th>면적</th>
                    </tr>
                    <tr>
                        <tr v-for="(result, index) in getHousedeal" :key="index">
                        <td>
                            {{ getHousedeal[0] }}
                        </td>
                        <td>
                            {{ getHousedeal }}
                        </td>
                        <td>
                            {{ getHousedeal }}
                        </td>
                    </tr>
                </table> -->
      </div>
    </div>
  </div>
</template>
<script>
import { Button, FormGroupInput } from '@/components';
import axios from 'axios';

export default {
  name: 'house',
  bodyClass: 'house-page',
  components: {
    [Button.name]: Button,
    [FormGroupInput.name]: FormGroupInput,
  },
  data() {
    return {
      code: '',
      type: '',
      address: '',
      house: [],
      apt: {
        no: '',
        name: '',
        lat: 0,
        lng: 0,
      },
      housedeal: '',
    };
  },
  created() {
    // 해당 동 매물 가져오고 마커 찍기
    this.code = this.$route.query.code; // 동 코드
    this.type = this.$route.query.type;
    this.apt.no = this.$route.query.no;
    console.log(this.code);
    console.log(this.apt.no);
    console.log(this.type);

    if (this.code == null) {
      console.log('You Are Here');
      navigator.geolocation.getCurrentPosition(
        this.handleLocation,
        this.handleError
      );
      // 현재 위치 동 이름, 동 코드 알아오기
    } else {
      axios
        .get('http://localhost/house/' + this.code)
        .then((response) => {
          var result = response.data;
          this.address = result[0].jibun; // 'ㅇㅇ구 ㅇㅇ시 ㅇㅇ동' data 담기
          for (var i = 0; i < result.length; i++) {
            //console.log(result[i]);
            this.house.push({
              aptName: result[i].aptName,
              lat: Number(result[i].floor),
              lng: Number(result[i].area),
              dealAmount: result[i].dealAmount,
            });
          }
          google.maps.event.addDomListener(
            // map 그리러 가기
            window,
            'load',
            this.initialize(this.house) // house에 담긴 list 넘기기
          );
        })
        .catch();
    }
  },
  methods: {
    // map 그리기
    initialize(list) {
      //console.log(list);
      var mapOptions = {
        zoom: 15, // 지도를 띄웠을 때의 줌 크기
        mapTypeId: google.maps.MapTypeId.ROADMAP,
      };

      var map = new google.maps.Map(
        document.getElementById('map-canvas'),
        mapOptions
      );

      var address = this.address; // ㅇㅇ시 ㅇㅇ구 ㅇㅇ동
      var type = this.type;
      var no = this.apt.no;
      var geocoder = new google.maps.Geocoder();
      geocoder.geocode({ address: address }, function(results, status) {
        if (status == google.maps.GeocoderStatus.OK) {
          console.log(type);
          // google map에서 'ㅇㅇ시 ㅇㅇ구 ㅇㅇ동'으로 검색한 곳을 center로 지정
          // (ㅇㅇ동사무소로 설정됨)
          if (type == 'dong') {
            //console.log(results[0].geometry.location);
            map.setCenter(results[0].geometry.location);
          } else if (type == 'apt') {
            console.log('>>>' + no);
            axios
              .get('http://localhost/houseInfo/' + no)
              .then((response) => {
                var position = {
                  lat: Number(response.data[0].lat),
                  lng: Number(response.data[0].lng),
                };
                console.log(position);
                map.setCenter(position);
                map.setZoom(18);
              })
              .catch((error) => {
                console.log(error);
              });
          }

          var marker = [];
          var infoWindow = [];
          for (let i = 0; i < list.length; i++) {
            // parameter로 받은 list 정보들로 마커 찍기
            var house = {
              lat: list[i].lat,
              lng: list[i].lng,
            };

            marker[i] = new google.maps.Marker({
              position: house,
              map: map,
              title: list[i].aptName,
            });

            infoWindow[i] = new google.maps.InfoWindow({
              content: list[i].aptName,
            });

            google.maps.event.addListener(marker[i], 'click', function() {
              for (var j = 0; j < list.length; j++) {
                if (j == i) {
                  infoWindow[i].open(map, marker[i]);
                } else {
                  infoWindow[j].close(map, marker[j]);
                }
              }
              map.setCenter(this.getPosition());
              map.setZoom(18);
            });

            marker[i].addListener('click', function() {
              var dong = address.split(' ')[2];
              var aptName = marker[i].title;
              console.log('marker CLICK APT : ' + aptName + ' / ' + dong);
              axios
                .get('http://localhost/detail/' + dong + '/' + aptName)
                .then((response) => {
                  this.housedeal = response.data;
                  console.log(
                    'SUCCESS : ' +
                      this.housedeal.length +
                      ' ' +
                      this.housedeal[0].aptName
                  );

                  var Info_aptName = document.getElementById('Info_aptName');
                  Info_aptName.innerHTML = this.housedeal[0].aptName;
                  var Info_deal = document.getElementById('Info_deal');
                  var makeTable =
                    '<table style="background-color: white; margin-bottom: 50px; text-align:center;"><tr style="border-bottom: 10px solid white;"><th>거래금액</th><th>거래일자</th><th>면적</th><th>층수</th></tr>';

                  for (var j = 0; j < response.data.length; j++) {
                    makeTable +=
                      '<tr style="border-bottom: 10px solid white;"><td>' +
                      response.data[j].dealAmount +
                      '만원</td>';
                    makeTable +=
                      '<td>' +
                      response.data[j].dealYear +
                      '년 ' +
                      response.data[j].dealMonth +
                      '월 ' +
                      response.data[j].dealDay +
                      '일</td>';
                    makeTable += '<td>' + response.data[j].area + '㎡</td>';
                    makeTable +=
                      '<td>' + response.data[j].floor + '층</td></tr>';
                  }

                  makeTable += '</table>';
                  Info_deal.innerHTML = makeTable;

                  // var Info_dealAmount = document.getElementById(
                  //     'Info_dealAmount'
                  // );
                  // Info_dealAmount.innerHTML =
                  //     '<i class="fa fa-angle-right"></i> 거래금액 : ' +
                  //     this.housedeal[0].dealAmount +
                  //     '만원';
                  // var Info_dealDate = document.getElementById(
                  //     'Info_dealDate'
                  // );
                  // Info_dealDate.innerHTML =
                  //     '<i class="fa fa-angle-right"></i> 거래일자 : ' +
                  //     this.housedeal[0].dealYear +
                  //     '년 ' +
                  //     this.housedeal[0].dealMonth +
                  //     '월 ' +
                  //     this.housedeal[0].dealDay +
                  //     '일';
                  // var Info_area = document.getElementById(
                  //     'Info_area'
                  // );
                  // Info_area.innerHTML =
                  //     '<i class="fa fa-angle-right"></i> 거래면적 : ' +
                  //     this.housedeal[0].area +
                  //     '㎡';
                  // var Info_floor = document.getElementById(
                  //     'Info_floor'
                  // );
                  // Info_floor.innerHTML =
                  //     '<i class="fa fa-angle-right"></i> 거래층수 : ' +
                  //     this.housedeal[0].floor +
                  //     '층';
                })
                .catch((error) => {
                  console.log(error);
                });

              //Info_aptName.text('${this.housedeal[0].aptName}');
              var mapInfo = document.getElementById('map-info');
              mapInfo.style.display = 'inline';
            });
          }
        } else {
          alert(
            'Geocode was not successful for the following reason: ' + status
          );
        }
      });
    },
    handleLocation(position) {
      var posStr = 'latitude : ' + position.coords.latitude + '<br/>';
      posStr += 'longitude : ' + position.coords.longitude; // 좌표보기

      console.log('handleLocation : ' + posStr);

      var latlng = new google.maps.LatLng(
        position.coords.latitude,
        position.coords.longitude
      ); // 위치 정보
      var mapOption = {
        zoom: 13,
        center: latlng,
        mapTypeControl: false,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
      }; // 지도 옵션

      var map = new google.maps.Map(
        document.getElementById('map-canvas'),
        mapOption
      ); // 지도 만들기

      //geocode;

      new google.maps.Marker({
        position: latlng,
        map: map,
        title: 'here!!',
      }); // 위치 표시
    },
    handleError(err) {
      if (err.code == 1) {
        outDiv.innerHTML = '사용자가 위치정보 공유를 거부함';
      } else {
        outDiv.innerHTML = '에러발생 : ' + err.code;
      }
    },
    mapInfoClose() {
      console.log('REMOVE CLICK');
      var mapInfo = document.getElementById('map-info');
      mapInfo.style.display = 'none';
    },
  },
  computed: {
    getHousedeal() {
      console.log('computed : ' + this.housedeal);
      return this.housedeal;
    },
  },
};
</script>
<style>
#map-canvas {
  position: relative;
}
#map-info {
  position: absolute;
  background-color: white;
  right: 0;
  top: 0;
  width: 30%;
  height: 600px;
  padding: 25px 50px;
  opacity: 0.9;
  margin-top: 70px;
  display: none;
}
ul.elements {
  list-style: none;
  margin: 0;
  padding: 0;
}
</style>
