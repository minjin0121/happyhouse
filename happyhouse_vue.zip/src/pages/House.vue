<template>
  <div>
    <div class="page-header page-header-small">
      <parallax
        class="page-header-image"
        style="background-image: url('img/bg6.jpg')"
      >
      </parallax>
      <div class="content-center">
        <div class="container">
          <h1 class="title">This is Happy House.</h1>
          <div class="text-center"></div>
        </div>
      </div>
    </div>
    <div id="map-canvas" class="map-canvas" style="height: 600px;"></div>
    <div class="section section-about-us">
      <div class="container">
        <div class="row">
          <div class="col-md-8 ml-auto mr-auto text-center">
            <h2 class="title">Who we are?</h2>
            <h5 class="description">
              According to the National Oceanic and Atmospheric Administration,
              Ted, Scambos, NSIDClead scentist, puts the potentially record low
              maximum sea ice extent tihs year down to low ice extent in the
              Pacific and a late drop in ice extent in the Barents Sea.
            </h5>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { Button, FormGroupInput } from '@/components';
import axios from 'axios';
export default {
  name: 'landing',
  bodyClass: 'landing-page',
  components: {
    [Button.name]: Button,
    [FormGroupInput.name]: FormGroupInput,
  },
  data() {
    return {
      code: '',
      type: '',
      address: '',
      house: [],
      apt: {
        no: '',
        name: '',
        lat: 0,
        lng: 0,
      },
    };
  },
  created() {
    // 해당 동 매물 가져오고 마커 찍기
    this.code = this.$route.query.code;
    this.type = this.$route.query.type;
    this.apt.no = this.$route.query.no;
    console.log(this.apt.no);
    console.log(this.type);
    axios
      .get('http://localhost/house/' + this.code)
      .then((response) => {
        var result = response.data;
        this.address = result[0].jibun; // 'ㅇㅇ구 ㅇㅇ시 ㅇㅇ동' data 담기
        for (var i = 0; i < result.length; i++) {
          //console.log(result[i]);
          this.house.push({
            aptName: result[i].aptName,
            lat: Number(result[i].floor),
            lng: Number(result[i].area),
            dealAmount: result[i].dealAmount,
          });
        }
        google.maps.event.addDomListener(
          // map 그리러 가기
          window,
          'load',
          this.initialize(this.house) // house에 담긴 list 넘기기
        );
      })
      .catch();
  },
  methods: {
    // map 그리기
    initialize(list) {
      //console.log(list);
      var mapOptions = {
        zoom: 18, // 지도를 띄웠을 때의 줌 크기
        mapTypeId: google.maps.MapTypeId.ROADMAP,
      };

      var map = new google.maps.Map(
        document.getElementById('map-canvas'),
        mapOptions
      );

      var address = this.address; // ㅇㅇ시 ㅇㅇ구 ㅇㅇ동
      var type = this.type;
      var no = this.apt.no;
      var geocoder = new google.maps.Geocoder();
      geocoder.geocode({ address: address }, function(results, status) {
        if (status == google.maps.GeocoderStatus.OK) {
          console.log(type);
          // google map에서 'ㅇㅇ시 ㅇㅇ구 ㅇㅇ동'으로 검색한 곳을 center로 지정
          // (ㅇㅇ동사무소로 설정됨)
          if (type == 'dong') {
            //console.log(results[0].geometry.location);
            map.setCenter(results[0].geometry.location);
          } else if (type == 'apt') {
            console.log('>>>' + no);
            axios
              .get('http://localhost/houseInfo/' + no)
              .then((response) => {
                var position = {
                  lat: Number(response.data[0].lat),
                  lng: Number(response.data[0].lng),
                };
                console.log(position);
                map.setCenter(position);
              })
              .catch((error) => {
                console.log(error);
              });
          }

          var marker = [];
          var content = [];
          for (let i = 0; i < list.length; i++) {
            // parameter로 받은 list 정보들로 마커 찍기
            var house = {
              lat: list[i].lat,
              lng: list[i].lng,
            };
            marker[i] = new google.maps.Marker({
              position: house,
              map: map,
              title: list[i].aptName,
            });
            content[i] =
              list[i].aptName + '<br>매물 가격 : ' + list[i].dealAmount + ' ~'; // 말풍선 안에 들어갈 내용

            // 지금 마커가 자신의 content를 못 담고 있음...
            // var infowindow = new google.maps.InfoWindow({
            //   content: content,
            // });
            // google.maps.event.addListener(marker, 'click', function() {
            //   infowindow.open(map, marker);
            // });
            //console.log(content[i]);
            var infoWindow = new google.maps.InfoWindow({
              content: content[i],
            });
            marker[i].addListener('click', function() {
              alert(i + ' ' + content[i]);
              infoWindow.open(map, marker[i]);
            });
          }
        } else {
          alert(
            'Geocode was not successful for the following reason: ' + status
          );
        }
      });
    },
  },
};
</script>
<style></style>
