<template>
  <div id="BoardHome">
    <center>
      <img alt="Vue logo" src="../assets/BoardLogo_MJNH.jpg" />
      <!-- <h2>Home : 게시판 목록</h2> -->
      <div id="BoardSearchWrap">
        <!-- <select v-model="keyword"></select> -->
        <select id="type" name="type">
          <option value="title">제목</option>
          <option value="name">작성자</option> </select
        >&nbsp;
        <input type="text" v-model="keyword" @keyup.enter="search" />
        <button @click="search">검색</button>
      </div>
      <div id="BoardInsertWrap">
        <button @click="moveBoardInsert">등록</button>
      </div>
      <div id="BoardListWrap">
        <table id="BoardList">
          <colgroup>
            <col width="6%" />
            <col width="30%" />
            <col width="10%" />
            <col width="10%" />
            <col width="10%" />
          </colgroup>
          <tr>
            <th>번호</th>
            <th>제목</th>
            <th>작성자</th>
            <th>날짜</th>
            <th>답변</th>
          </tr>
          <tr
            v-for="(row, index) in boardList"
            :key="index"
            @click="moveBoardDetail(index)"
          >
            <td>{{ row.num }}</td>
            <td>{{ row.title }}</td>
            <td>{{ row.name }}</td>
            <td>{{ row.wdate }}</td>
            <td v-show="row.answer == null" style="color: gray;">
              답변예정
            </td>
            <td
              v-show="row.answer != null"
              style="color: blue; font-weight: bold;"
            >
              답변완료
            </td>
          </tr>
        </table>
      </div>
    </center>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      boardList: '',
      keyword: '',
    };
  },
  mounted() {
    this.selectAll();
  },
  methods: {
    selectAll() {
      axios
        .get('http://localhost/boards')
        .then((response) => {
          this.boardList = response.data;
          console.log('SUCCESS : ' + response.data);
        })
        .catch((response) => {
          console.log('FAIL : ' + response.status);
        });
    },
    countUp(num) {
      axios
        .put('http://localhost/boards/' + num)
        .then((response) => {
          console.log('SUCCESS : ' + response);
        })
        .catch((response) => {
          console.log('FAIL : ' + response.status);
        });
    },
    moveBoardDetail(index) {
      console.log(
        'sendBoardNum : ' + index + ' / ' + this.boardList[index].num
      );
      this.countUp(this.boardList[index].num);
      this.$router.push({
        path: './boardDetail',
        query: { num: this.boardList[index].num },
      });
    },
    moveBoardInsert() {
      console.log('moveBoardInsert');
      this.$router.push('./boardInsert');
    },
    search() {
      var val = document.getElementById('type');
      var type = val.options[val.selectedIndex].value;
      console.log('search : ' + this.keyword + ' ' + type);
      if (type == 'title') {
        axios
          .get('http://localhost/boards/title/' + this.keyword)
          .then((response) => {
            this.boardList = response.data;
            console.log('SUCCESS : ' + response.data.length);
          })
          .catch((response) => {
            console.log('FAIL : ' + response.status);
          });
      } else {
        axios
          .get('http://localhost/boards/name/' + this.keyword)
          .then((response) => {
            this.boardList = response.data;
            console.log('SUCCESS : ' + response.data.length);
          })
          .catch((response) => {
            console.log('FAIL : ' + response.status);
          });
      }
    },
  },
};
</script>

<style>
#BoardInsertWrap {
  text-align: center;
  margin-left: 50%;
  margin-bottom: 30px;
}
#BoardList {
  margin: auto;
  margin-bottom: 50px;
}
#BoardList th {
  border-top: 1px solid #888;
}
#BoardList th,
#BoardList td {
  border-bottom: 1px solid #eee;
  padding: 5px 0;
}
#BoardList td.txt_left {
  text-align: left;
}
</style>
