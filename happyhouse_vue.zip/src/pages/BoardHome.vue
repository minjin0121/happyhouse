<template>
  <div>
    <div class="page-header page-header-small">
      <parallax
        class="page-header-image"
        style="background-image: url('img/bg2.jpg');"
      >
      </parallax>
      <div class="content-center">
        <div class="container">
          <h1 class="title">Q & A</h1>
          <h5>무엇이든 물어보세요!</h5>
          <div class="text-center"></div>
        </div>
      </div>
    </div>
    <div id="BoardHome" class="section">
      <!-- <h2>Home : 게시판 목록</h2> -->
      <div id="BoardSearchWrap" style="text-align: right;">
        <!-- <select v-model="keyword"></select> -->
      </div>
      <div id="BoardInsertWrap">
        <select id="type" name="type">
          <option value="title">제목</option>
          <option value="name">작성자</option> </select
        >&nbsp;
        <input type="text" v-model="keyword" @keyup.enter="search" />
        <n-button type="primary" link @click="search">
          <i class="now-ui-icons ui-1_zoom-bold" style="color:blue;"></i>
        </n-button>
        <!-- <button @click="moveBoardInsert">등록</button> -->
      </div>
      <div id="BoardListWrap">
        <collapse :animation-duration="500" id="collapse_style">
          <collapse-item
            v-for="(row, index) in boardList"
            :key="index"
            :title="row.title"
          >
            <div>
              <div class="section" style="margin-left:-20%;">
                <table id="BoardDetail">
                  <tr>
                    <th>제목</th>
                    <td colspan="3">{{ row.title }}</td>
                  </tr>
                  <tr>
                    <th width="10%">작성자</th>
                    <td width="40%">{{ row.name }}</td>
                  </tr>
                  <tr>
                    <th>작성일시</th>
                    <td>{{ row.wdate }}</td>
                    <th>조회수</th>
                    <td style="text-align:left;">{{ row.count }}</td>
                  </tr>
                  <tr>
                    <th>내용</th>
                    <td colspan="3">{{ row.content }}</td>
                  </tr>
                </table>

                <table id="BoardDetail">
                  <tr v-show="row.answer != null">
                    <th
                      width="10%"
                      style="color: blue; font-weight: bold; font-size:16px;"
                    >
                      답변
                    </th>
                    <td><p v-html="row.answer"></p></td>
                  </tr>
                </table>
              </div>
              <center>
                <div id="BoardButtonWrap" style="margin-left:-20%">
                  <n-button type="info" @click="update(row.num)">
                    수정하기
                  </n-button>
                  <n-button type="danger" @click="remove(row.num)">
                    삭제하기
                  </n-button>
                </div>
              </center>
            </div>
          </collapse-item>
        </collapse>

        <div id="BoardInsertWrap">
          <n-button type="default" outline round @click="moveBoardInsert">
            <i class="now-ui-icons shopping_tag-content"></i> 글 작성
          </n-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import { Button, FormGroupInput, Collapse, CollapseItem } from '@/components';
export default {
  components: {
    [Button.name]: Button,
    [FormGroupInput.name]: FormGroupInput,
    Collapse,
    CollapseItem,
  },
  data() {
    return {
      boardList: '',
      keyword: '',
      ans: '',
      name: this.$session.get('userID'),
    };
  },
  mounted() {
    this.name = this.$session.get('userID');
    console.log(this.name);
    this.selectAll();
  },
  methods: {
    selectAll() {
      axios
        .get('http://localhost/boards')
        .then((response) => {
          this.boardList = response.data;
          console.log('SUCCESS : ' + response.data);
        })
        .catch((response) => {
          console.log('FAIL : ' + response.status);
        });
    },
    countUp(num) {
      axios
        .put('http://localhost/boards/' + num)
        .then((response) => {
          console.log('SUCCESS : ' + response);
        })
        .catch((response) => {
          console.log('FAIL : ' + response.status);
        });
    },
    moveBoardInsert() {
      console.log('moveBoardInsert');
      this.$router.push('./boardInsert');
    },
    search() {
      var val = document.getElementById('type');
      var type = val.options[val.selectedIndex].value;
      console.log('search : ' + this.keyword + ' ' + type);
      if (type == 'title') {
        axios
          .get('http://localhost/boards/title/' + this.keyword)
          .then((response) => {
            this.boardList = response.data;
            console.log('SUCCESS : ' + response.data.length);
          })
          .catch((response) => {
            console.log('FAIL : ' + response.status);
          });
      } else {
        axios
          .get('http://localhost/boards/name/' + this.keyword)
          .then((response) => {
            this.boardList = response.data;
            console.log('SUCCESS : ' + response.data.length);
          })
          .catch((response) => {
            console.log('FAIL : ' + response.status);
          });
      }
    },
    update(num) {
      this.$router.push({
        path: './boardUpdate',
        query: { num: num },
      });
    },
    remove(num) {
      axios
        .delete('http://localhost/boards/' + num)
        .then((response) => {
          console.log('SUCCESS : ' + response);
          alert('게시글이 삭제되었습니다!');
          this.$router.push({ path: './board', query: this.body });
        })
        .catch((response) => {
          console.log('FAIL : ' + response.status);
        });
    },
  },
};
</script>

<style>
#BoardInsertWrap {
  text-align: center;
  margin-left: 50%;
  margin-bottom: 30px;
}
#BoardListWrap {
  text-align: left;
  margin-left: 20%;
  margin-bottom: 30px;
}
#BoardList {
  margin: auto;
  margin-bottom: 50px;
}
#BoardList th {
  border-top: 1px solid #888;
}
#BoardList th,
#BoardList td {
  border-bottom: 1px solid #eee;
  padding: 5px 0;
}
#BoardList td.txt_left {
  text-align: left;
}
#BoardDetail {
  margin: auto;
  margin-bottom: 50px;
  width: 70%;
}
#BoardDetail th,
#BoardDetail td {
  border-bottom: 1px solid #eee;
  padding: 5px 0;
}
#BoardDetail td.txt_left {
  text-align: left;
}
#collapse_style {
  text-align: left;
  font-size: 20px;
  color: #888;
}
</style>
