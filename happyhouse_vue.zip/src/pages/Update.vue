<template>
  <div
    class="section section-signup"
    style="background-image: url('img/bg2.jpg'); background-size: cover; background-position: top center; min-height: 700px;"
  >
    <div class="container">
      <div class="row">
        <card class="card-signup" header-classes="text-center" color="black">
          <template slot="header">
            <h3 class="card-title title-up">
              {{ this.id }}님의<br />회원정보 수정
            </h3>
          </template>
          <template>
            <fg-input
              type="password"
              class="no-border"
              placeholder="비밀번호"
              addon-left-icon="now-ui-icons objects_key-25"
              v-model="pass"
            >
            </fg-input>

            <fg-input
              type="password"
              class="no-border"
              placeholder="비밀번호 확인"
              addon-left-icon="now-ui-icons objects_key-25"
              v-model="pass0"
              @keyup="confirmPass"
            >
            </fg-input>

            <p v-html="resultPass"></p>
            <!-- 비밀번호 일치 여부 나오는 곳 -->

            <fg-input
              type="text"
              class="no-border"
              placeholder="닉네임"
              addon-left-icon="now-ui-icons users_single-02"
              v-model="name"
            >
            </fg-input>

            <fg-input
              type="text"
              class="no-border"
              placeholder="주소"
              addon-left-icon="now-ui-icons location_pin"
              v-model="addr"
            >
            </fg-input>

            <fg-input
              type="tel"
              class="no-border"
              placeholder="전화번호"
              addon-left-icon="now-ui-icons tech_mobile"
              v-model="tel"
            >
            </fg-input>
          </template>
          <div class="card-footer text-center">
            <n-button type="default" round size="lg" @click="update()">
              회원정보 수정
            </n-button>
          </div>
          <div class="card-footer text-center">
            <n-button
              type="default"
              link
              @click.native="modals.classic = true"
              style="margin-left:75%;"
            >
              회원 탈퇴
            </n-button>
          </div>
        </card>
      </div>
    </div>
    <div>
      <modal :show.sync="modals.classic" headerClasses="justify-content-center">
        <h4 slot="header" class="title title-up">탈퇴하시겠어요?</h4>
        <fg-input
          type="password"
          class="no-border"
          placeholder="비밀번호를 입력해주세요."
          addon-left-icon="now-ui-icons ui-1_email-85"
          v-model="removePass"
        >
        </fg-input>

        <template slot="footer">
          <n-button type="danger" @click="remove()" style="margin-left:80%;"
            >탈퇴하기</n-button
          >
        </template>
      </modal>
    </div>
  </div>
</template>
<script>
import { Card, FormGroupInput, Button } from '@/components';
import { Modal } from '@/components';
import axios from 'axios';

export default {
  components: {
    Modal,
    Card,
    [Button.name]: Button,
    [FormGroupInput.name]: FormGroupInput,
  },
  data() {
    return {
      modals: {
        classic: false,
      },
      id: this.$session.get('userID'),
      pass: '',
      pass0: '', // 비밀번호 재차 확인을 위한 data
      removePass: '',
      addr: '',
      name: '',
      tel: '',
      resultPass: '', // pw 일치 여부
      flag: false,
    };
  },
  created() {
    axios
      .get('http://localhost/member/info/' + this.id)
      .then((response) => {
        console.log(response);
        this.name = response.data.memberNAME;
        this.addr = response.data.memberADDR;
        this.tel = response.data.memberTEL;
      })
      .catch((error) => {
        console.log(error);
      });
  },
  methods: {
    // 회원가입
    update() {
      axios
        .put('http://localhost/member', {
          memberID: this.id,
          memberPW: this.pass,
          memberNAME: this.name,
          memberTEL: this.tel,
          memberADDR: this.addr,
        })
        .then((response) => {
          console.log(response);
          // STS 에서 return type을 boolean으로 받아 성공/실패 여부를 받음
          if (response.data == true) {
            alert('수정이 완료되었습니다!');
            this.$router.push({
              path: '/profile',
            });
          } else {
            alert('회원정보 수정에 실패했습니다. 다시 시도해주세요.');
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    // 비밀번호 일치 여부
    confirmPass() {
      if (this.pass != this.pass0) {
        this.resultPass = '비밀번호가 일치하지 않습니다.';
      } else {
        this.resultPass = '';
      }
    },
    remove() {
      console.log(this.removePass, this.id);
      this.modals.classic = false;
      axios
        .post('http://localhost/member/login', {
          memberID: this.id,
          memberPW: this.removePass,
          memberNAME: '',
          memberTEL: '',
          memberADDR: '',
        })
        .then((response) => {
          console.log(response);
          if (response.data == true) {
            axios
              .post('http://localhost/member/delete', {
                memberID: this.id,
                memberPW: this.removePass,
                memberNAME: '',
                memberTEL: '',
                memberADDR: '',
              })
              .then((response) => {
                console.log(response);
                if (response.data == true) {
                  this.$session.set('userID', '');
                  alert('탈퇴가 완료되었습니다');
                  this.$router.push({
                    path: '/',
                  });
                }
              })
              .catch((error) => {
                console.log(error);
              });
          } else {
            alert('비밀번호를 다시 입력해주세요.');
            this.removePass = '';
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
  },
};
</script>
<style></style>
