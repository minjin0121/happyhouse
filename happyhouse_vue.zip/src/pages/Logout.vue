<template>
  <main-navbar></main-navbar>
</template>

<script>
import MainNavbar from '../layout/MainNavbar.vue';
export default {
  components: { MainNavbar },
  created() {
    console.log('로그아웃');
    this.$session.set('userID', '');
    alert('로그아웃 되었습니다.' + this.$session.get('userID'));
    this.$router.push({
      path: '/',
    });
    window.location.reload('/');
  },
  methods: {
    logout() {},
  },
};
</script>

<style></style>
